#!/usr/bin/env python

import sys
import numpy as np
from matplotlib import pyplot as pl
from astropy.io import fits


def rms(data):
    """Computes the rms around the median of the data

    Keyword arguments:
    data -- a numpy array
    """
    x = 0.0

    # TODO: Write your code here

    return x


def sigma_clip(data, n, m):
    """Perform sigma-clipping on the provided data

    Keyword arguments:
    data -- a numpy array
    n -- number of standard deviations away from the median
    m -- max number of iterations
    """
    low, high = 0.0, 0.0

    # TODO: Write your code here

    return low, high


def rms_map(data, rows, cols, n, m):
    """Returns an rms map of the provided data

    Keyword arguments:
    data -- a numpy 2 dimensional array
    rows -- number of rows to divide image into
    cols -- number of columns to divide image into
    n -- max number of standard deviations away from centroid
    m -- max number of iterations
    """
    rmsmap = np.zeros((rows, cols))

    # TODO: Write your code here

    return rmsmap


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print "Usage: {} <image.fits>".format(sys.argv[0])
        sys.exit(1)

    print "Reading {} as fits image:".format(sys.argv[1])
    img = fits.open(sys.argv[1])

    shape = (img[0].header['NAXIS1'], img[0].header['NAXIS1'])
    print " Object: {}".format(img[0].header['OBJECT'])
    print " Date:   {}".format(img[0].header['DATE-OBS'])
    print " Size:   {}x{}".format(shape[0], shape[1])

    data = img[0].data[0,0]
    pl.imshow(data)
    pl.savefig('raw.png', format='png')
    pl.close()

    
    low, high = sigma_clip(data, 2, 10)
    print "\nrms:         {}".format(rms(data))
    print "lower bound: {}".format(low)
    print "upper bound: {}".format(high)

    rmsmap = rms_map(data, shape[0]/64, shape[1]/64, 4, 10)
    pl.imshow(rmsmap)
    pl.colorbar()
    pl.savefig('rmsmap.png', format='png')
    pl.close()
    print "\nSaved image as raw.png"
    print "Saved rms map as rmsmap.png"
    
